        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">
 <!-- Topbar -->
 <?php $this->load->view('user/template/navbar'); ?>

<!-- End of Topbar -->
        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">


                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <h3><?= $title?></h3>
                    

                    <!-- Page Heading -->
        <div class="card shadow mb-4">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table  class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No.</th>
                                            <th>No. Tiket</th>
                                            <th>Departemen</th>
                                            <th>Nama Tiket</th>
                                            <th>Masalah</th>
                                            <th>Solusi</th>
                                            <th>Tanggal Ajuan</th>
                                            <th>Status</th>
                                            <th>Opsi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $no=1;
                                        foreach ((array)$row as $key=> $user) {?>                                         
                                           <tr>
                                            <td><?=$no++?></td>
                                            <!-- <td><?=$user->ID_TIKET ?></td> -->
                                            <td><?=$user->DEPARTEMEN ?></td>
                                            <td><?=$user->NAMA_TIKET ?></td>
                                            <td><?=$user->MASALAH?></td>
                                            <td><?=$user->SOLUSI ?></td>
                                            <td><?=$user->TANGGAL ?></td>
                                            <td><?=$user->STATUS ?></td>
                                            <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-solid fa-faw fa-file-alt" data-toggle="modal" data-target="#exampleModal" ></i></button></td>
                                        </tr>
                                        <?php
                                        }?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
           </div>

                </div>
                <!-- modals -->
                        <form action="" method="post">
                        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                <div class="modal-header bg-gray-900">
                                    <h5 class="modal-title" id="exampleModalLabel">Ubah Profil</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                <!-- input -->
                                <div class="row mb-3 ml-3">
                            <label for="nama" class="col-sm-3 col-form-label">NIP</label>
                            <div class="col-sm-7">
                              <input type="text" class="form-control" id="nama">
                            </div>
                          </div>
                          <div class="row mb-3 ml-3">
                            <label for="nama" class="col-sm-3 col-form-label">Nama Lengkap</label>
                            <div class="col-sm-7">
                              <input type="text" class="form-control" id="nama">
                            </div>
                          </div>
                          <div class="row mb-3 ml-3">
                            <label for="masalah" class="col-sm-3 col-form-label">Email</label>
                            <div class="col-sm-7">
                              <input type="email" class="form-control" id="masalah"></textarea>
                            </div>
                          </div>
                          <div class="row mb-3 ml-3">
                            <label for="tgl" class="col-sm-3 col-form-label">Departemen</label>
                            <div class="col-sm-7">
                              <input type="text" class="form-control" id="tgl">
                            </div>
                          </div>
                          <div class="row mb-3 ml-3">
                            <label for="tgl" class="col-sm-3 col-form-label">Nomor Telepon</label>
                            <div class="col-sm-7">
                              <input type="text" class="form-control" id="tgl">
                            </div>
                          </div>
                                </div>
                                <div class="modal-footer">
                                <button type="button" class="btn btn-primary">Simpan</button>
                                <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                                </div>
                                </div>
                            </div>
                            </div>
                        </form>
                        <!-- modals end -->

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

